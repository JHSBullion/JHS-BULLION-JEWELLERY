window.goldPrices = {
  "999": { "current": 999, "diff": -213 },
  "916": { "current": 999, "diff": -213 },
  "835": { "current": 999, "diff": -213 },
  "750": { "current": 999, "diff": -213 },
  "375": { "current": 999, "diff": -222 }
};